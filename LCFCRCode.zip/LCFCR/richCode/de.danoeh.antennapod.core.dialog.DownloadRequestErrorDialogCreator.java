download error dialog creator create alert exception happen message title neutral button string show 
