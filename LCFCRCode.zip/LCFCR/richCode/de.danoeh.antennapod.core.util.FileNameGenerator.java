file generator generate valid filename give string char array method return illegal character length space append trim empty build filter range 
common library time removed common text library time 