gpodnet tag read string int title usage describe content write parcel create array 
