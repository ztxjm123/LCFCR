gpodnet podcast string title description subscriber logo website mygpo link 
