proxy config direct http 
add sock proxy network setting add bracket condition add line proxyconfig add sock proxy network setting 