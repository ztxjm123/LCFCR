task callback impl automatic download algorithm episode cache cleanup 
