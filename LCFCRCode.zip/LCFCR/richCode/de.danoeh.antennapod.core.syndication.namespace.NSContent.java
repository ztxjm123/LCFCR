content handle element start end equal current item buf encode string 
