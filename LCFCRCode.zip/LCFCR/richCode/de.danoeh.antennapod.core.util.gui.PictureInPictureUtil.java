picture util support package manager system mode 
