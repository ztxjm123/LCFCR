dublin core handle element start end current item content buf tagstack size peek tag equal string pub date 
