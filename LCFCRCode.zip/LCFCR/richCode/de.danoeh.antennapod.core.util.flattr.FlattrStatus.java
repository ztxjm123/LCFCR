flattr status instance set unflattred queue flattrable time millis long actual minimum 
