sleep timer preference init user class throw illegal argument exception context share apply put int string edit time unit milli millis vibrate boolean shake reset auto enable 
error prone error 