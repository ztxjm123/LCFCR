simple chapter handle element start current item equal set time string add end 
