favorite event add remove string append 
