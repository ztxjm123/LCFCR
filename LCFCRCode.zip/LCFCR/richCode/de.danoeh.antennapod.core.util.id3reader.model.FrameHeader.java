frame header string format binary 
