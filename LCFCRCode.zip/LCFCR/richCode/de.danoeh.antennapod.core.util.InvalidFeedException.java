invalid feed exception throw attribute 
enable deprecation serial linting 