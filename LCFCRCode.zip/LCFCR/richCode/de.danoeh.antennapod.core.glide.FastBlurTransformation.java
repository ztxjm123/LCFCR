blur transformation simple fast transform extract thumbnail width height pixel max min ab 
checkstyle change enforce multiplevariabledeclarations checkstyle upgraded glide version 