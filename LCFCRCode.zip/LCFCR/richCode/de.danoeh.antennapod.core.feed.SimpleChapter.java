simple chapter type update 
