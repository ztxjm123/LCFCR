common symbol 
