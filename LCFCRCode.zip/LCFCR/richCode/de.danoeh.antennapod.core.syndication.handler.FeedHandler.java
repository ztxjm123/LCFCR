feed handler type instance namespace aware parser file close 
