playback service callback impl player activity intent add flag queue notification icon resource 
single notification icon develop lock queue removed unused resource code warning 