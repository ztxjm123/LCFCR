playback completion date comparator compare medium 
