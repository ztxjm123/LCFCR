confirmation dialog create alert user confirm class handle event cancelation simple string cancel button press dismiss positive text negative title message listener 
