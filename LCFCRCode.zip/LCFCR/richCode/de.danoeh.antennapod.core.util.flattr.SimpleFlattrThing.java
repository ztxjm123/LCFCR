simple flattr title payment link status 
