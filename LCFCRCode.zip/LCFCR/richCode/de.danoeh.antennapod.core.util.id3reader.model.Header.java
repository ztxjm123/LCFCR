header size string 
