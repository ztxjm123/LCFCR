shake listener simple resume system service default sensor register unregister change sqrt accuracy 
