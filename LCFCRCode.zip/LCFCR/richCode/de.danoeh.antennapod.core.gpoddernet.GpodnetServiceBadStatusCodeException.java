gpodnet service bad status code exception 
enable deprecation serial linting 