gpodnet device string case caption type subscription 
