gpodnet service authentication exception 
enable deprecation serial linting 