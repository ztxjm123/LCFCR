search result additional information lrb find rrb importance component subtitle 
