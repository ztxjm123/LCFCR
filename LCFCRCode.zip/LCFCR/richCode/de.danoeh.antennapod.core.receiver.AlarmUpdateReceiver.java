alarm update receiver listen event make reset receive equal action initialize restart 
work manager feed update 