flattr service creator ensure instance class exist time create delete 
