feed file represent component download create object param location downloaded false true parameterwill interpret type int update attribute method read compare return equal exist change 
