gpodnet service exception 
enable deprecation serial linting 