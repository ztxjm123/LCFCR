unsupported feedtype exception type root element message 
enable deprecation serial linting 