feed medium event update 
unused code removed unused code 