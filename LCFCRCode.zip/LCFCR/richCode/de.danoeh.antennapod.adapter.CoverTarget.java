cover target load fail do not animate fit center disk cache strategy resource ready visibility 
crash encapsulated covertarget upgraded glide version 