d3 chapter identify tag attribute store parsing string type id3 
