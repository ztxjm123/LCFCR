feed filter term text list single word quote string return lsb rsb param compile find add replace group auto download item true size case title trim include exclude set length 
