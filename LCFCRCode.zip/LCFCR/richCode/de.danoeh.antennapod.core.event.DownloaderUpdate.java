downloader update d feed download show progress wheel action bar medium feedfile type add array string 
checkstyle change enforce multiplevariabledeclarations checkstyle 