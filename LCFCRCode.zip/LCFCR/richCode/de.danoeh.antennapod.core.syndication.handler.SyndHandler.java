synd handler superclass process syndication format push start element handle namespace character empty size tagstack append end pop prefix mapping equal key put match peek document item feed state 
