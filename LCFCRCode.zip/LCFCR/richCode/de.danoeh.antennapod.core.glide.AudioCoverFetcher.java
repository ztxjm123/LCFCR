audio cover fetcher load datum source embedded picture release cleanup cancel 
loading embedded picture upgraded glide version 