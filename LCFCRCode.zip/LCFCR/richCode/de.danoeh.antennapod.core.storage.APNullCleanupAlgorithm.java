cleanup algorithm remove perform default reclaimable item 
