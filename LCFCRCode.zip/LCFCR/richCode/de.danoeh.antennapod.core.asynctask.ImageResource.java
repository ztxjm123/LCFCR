image resource class implement provide access load picasso library location return local path 
