download status comparator compare completion date downloadstatus object 
