permutor pas list method case simple comparator work lrb random smart shuffle rrb param type element reorder queue modifiable 
