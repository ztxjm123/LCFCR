flattr status fetcher fetch list flattred database background thread run priority current retrieve print stack trace message 
error prone error 