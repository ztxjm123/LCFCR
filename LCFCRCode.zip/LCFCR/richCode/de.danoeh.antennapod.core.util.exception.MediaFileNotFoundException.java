medium file find exception 
enable deprecation serial linting 