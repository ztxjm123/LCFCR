client configurator configure config class core package 
develop setting icon 