d3 reader exception 
enable deprecation serial linting 