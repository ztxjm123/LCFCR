vorbis comment chapter length vorbi string start time split convert substr index float key return vorbiscomment rxxx read throw reader exception substring int attribute type title set link 
