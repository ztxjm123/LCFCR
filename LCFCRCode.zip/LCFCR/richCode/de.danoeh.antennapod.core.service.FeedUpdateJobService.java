feed update job service start initialize application context auto stop 
work manager feed update code warning 