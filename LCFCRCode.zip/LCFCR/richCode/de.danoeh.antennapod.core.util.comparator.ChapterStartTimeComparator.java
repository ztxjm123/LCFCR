chapter start time comparator compare 
