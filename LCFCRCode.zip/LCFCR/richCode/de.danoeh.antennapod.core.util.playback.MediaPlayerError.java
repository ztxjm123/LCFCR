medium player error utility class string human readable specific code 
medium player error message medium player error message 