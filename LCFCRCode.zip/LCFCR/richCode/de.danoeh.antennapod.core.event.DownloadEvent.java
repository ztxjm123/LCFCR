download event refresh string 
refresh item subscription view method readability develop update progress develop feedinfo fragment 