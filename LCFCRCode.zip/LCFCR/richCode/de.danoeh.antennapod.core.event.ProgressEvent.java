progress event start end string append 
progressevent database upgrade splash screen 