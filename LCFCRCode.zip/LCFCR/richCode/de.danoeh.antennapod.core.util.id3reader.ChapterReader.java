chapter reader start tag header frame id3 add string read byte skip title size decode link equal end find 
checkstyle rule enabled checkstyle rule 