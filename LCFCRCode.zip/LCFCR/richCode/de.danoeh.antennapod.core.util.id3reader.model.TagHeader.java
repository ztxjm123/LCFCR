tag header string version 
