feedtitle comparator compare title feed sort ignore case 
unused code removed unused code 