player widget receive update enable set string disabled share preference boolean put edit 
transparent widget code cleanup transparent widget code warning 