feed event string append 
sort podcast screen logic db persistence sort support podcast screen 