ap glide setting antenna pod option 
