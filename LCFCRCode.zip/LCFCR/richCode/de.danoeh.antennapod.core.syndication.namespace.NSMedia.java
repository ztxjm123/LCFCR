medium process tag http search yahoo mrs namespace handle element start equal mime type enclosure valid image current item long empty convert duration feed end string content buf description 
