search result comparator compare item base find lrb title chapter show note rrb section lexicographic order ideal due fact unicode component 
unused code removed unused code 