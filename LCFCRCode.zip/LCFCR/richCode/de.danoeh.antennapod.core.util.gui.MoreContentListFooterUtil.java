content list footer util utility method layout click listener load state find view visibility root 
code warning 