task callback class storage module automatic download algorithm return client implementation episode cache cleanup 
