import os

import javaNameItem
from similarityComputer import getFile


def clusterNum(number, item):
    outfile = open('result//AntennaPod//' + str(number) + '.txt', mode='a', encoding='utf-8')
    outfile.write(item)
    outfile.close()


if __name__ == '__main__':
    # 输入每个APP最后计算的相似度文档位置
    re = [line for line in
          open("C://Users//jiangyiwen//Desktop//similarity.txt", mode='r',
               encoding="utf-8")]
    for item in re:
        endNameReviewCluster = item.find("-issueNumber")
        ReviewClusterNum = item[13:endNameReviewCluster]
        # 按聚类主题存储
        clusterNum(ReviewClusterNum, item)
        if not os.path.exists('result//AntennaPod//' + ReviewClusterNum):
            os.makedirs('result//AntennaPod//' + ReviewClusterNum)
    # 读取并按java文件名进行存储
    for item in getFile("D://workspace//LCFCR//result//AntennaPod//"):
        beginNum = item.rfind("//")
        endNum = item.find(".txt")
        re1 = [line for line in
               open(item, mode='r',
                    encoding="utf-8")]
        # print(item[beginNum + 2:endNum])
        javaNameItem.printJavaNameList(re1, item[beginNum + 2:endNum])
