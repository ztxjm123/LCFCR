import os

import nltk
from nltk.corpus import stopwords


def spec_preprocess(doc_set):
    new_doc_set = []
    for doc in doc_set:
        new_doc_set.append(
            doc.replace('…', ' . ').replace("/", '.').replace("..", ".").replace('.', ' ').replace('"', '').replace(
                "\\", '').replace('-', ' ').replace('_', ' ').replace('(', ' ').replace(')', ' ').replace('*', ' ').replace('[',
                                                                                                          ' ').replace(
                ']', ' ').replace('\"', ' ').replace('\'', ' '))
    return new_doc_set


def removeRepeatElement(listEle):
    listEleNotRepeat = []
    for i in listEle:
        if i not in listEleNotRepeat:
            listEleNotRepeat.append(i)
    return listEleNotRepeat


def dealDocSet(doc_set):
    # 1.token化
    docs_tokenize = []
    for doc in doc_set:
        # 分句
        sens = nltk.sent_tokenize(doc)
        docWords = []
        for sent in sens:
            # 分词
            docWords = docWords + nltk.word_tokenize(sent)
        docs_tokenize.append(docWords)

    # 2.stopwords
    en_stop = stopwords.words("english")
    english_punctuations = ['', '\n', '\t', ',', '.', ':', ';', '?', '(', ')', '[', ']', '&', '!', '*',
                            '@', '#', '$', '%', '/', '"', "'", "-", "--", "•", "...", "..", "''", "``"]
    cn_punctuations = ['，', '。', '：', '；', '？', '（', '）', '【', '】', '&', '！',
                       '*', '@', '#', '￥', '%', '“', '”', "‘", "’", "—", "–", "◦", "…", "……", '<', '>']
    spec_stop = ["'s", "'t", "'ll", "'m", "'re", "'vt", "a's", '■', '◉', "n't", "'ve", "u", '0', '1', '2', '3', '4',
                 '5', '-1',
                 '6', '7', '8', '9', '❤', '*']

    def_list = []
    with open(r'D:\workspace\LCFCR\files\stopwords') as f:
        lines = f.readlines()
    for line in lines:
        def_list.append(line.strip())
    stopList = en_stop + english_punctuations + cn_punctuations + spec_stop + def_list
    docs_stop = []
    for doc in docs_tokenize:
        doc_stop = [token for token in doc if (not token in stopList) and (not str(token).isdigit())]
        docs_stop.append(doc_stop)
    # print("This is afterStop:", docs_stop)

    # 3.增加词性标注
    tags = set(['NN', 'NNS', 'VB', 'VBD', 'VBG', 'VBP', 'VBZ', 'JJ', 'JJS'])
    pos = []
    for doc in docs_stop:
        pos_tags = nltk.pos_tag(doc)
        ret = [posWord for posWord, pos in pos_tags if (pos in tags)]
        pos.append(ret)
    # print("This is POS:", pos)

    # 4.词汇还原Lemma
    lemma = nltk.WordNetLemmatizer()
    docs_lemma = []
    for doc in pos:
        doc_lemma = [lemma.lemmatize(token) for token in doc]
        docs_lemma.append(doc_lemma)
    # print("This is lemma:", len(docs_lemma))

    # 5.用字典纠正错误
    wordMapper = {}
    with open(r'D:\workspace\LCFCR\files\wordMapper.txt') as f:
        lines = f.readlines()
        for line in lines:
            key, value = line.strip().split(',')
            wordMapper[key] = value
    right_list = []
    for doc in docs_lemma:
        sen = []
        i = 0
        while i < len(doc):
            if doc[i] not in wordMapper.keys():
                sen.append(doc[i])
            else:
                sen.append(wordMapper[doc[i]])
            i = i + 1
        right_list.append(sen)
    # print("This is after wordMapper:", right_list)

    doc_removel = []
    for doc in right_list:
        if len(doc) >= 1:
            doc_removel.append(doc)

    listEle = []
    for doc in doc_removel:
        for token in doc:
            listEle.append(token)
    return listEle


def getFile(fileDir):
    fileList = []
    for root, dirs, files in os.walk(fileDir):
        for file in files:
            fileList.append(os.path.join(root, file))
    return fileList


def richCode(fileName):
    # read folder Processed java
    doc_set_code = [line.lower() for line in
                    open('D://workspace//processdata//' + fileName + '.txt',
                         mode='r',
                         encoding="ISO-8859-1")]
    # read folder commitDate
    doc_set_commit = [line.lower() for line in
                      open('D://workspace//commitData//' + fileName + '.txt',
                           mode='r',
                           encoding="ISO-8859-1")]
    doc_set_code = spec_preprocess(doc_set_code)
    codeFile = dealDocSet(doc_set_code)
    print("code token number " + str(len(removeRepeatElement(codeFile))), str(len(codeFile)))
    listCode = []
    for i in codeFile:
        listCode.append(i)
    doc_set_commit = spec_preprocess(doc_set_commit)
    commitFile = dealDocSet(doc_set_commit)
    print("commit token number " + str(len(removeRepeatElement(commitFile))), str(len(commitFile)))
    # rich code 文档的存储
    outfile = open('an//richCode//' + fileName + '.java', mode='a', encoding='utf-8')
    for codeItem in removeRepeatElement(listCode):
        outfile.write(codeItem + ' ')

    outfile.write('\n')
    for commitItem in commitFile:
        outfile.write(commitItem + ' ')

    outfile.close()
    print('----------' + fileName + ' richCode OK----------')


if __name__ == '__main__':
    # read folder commitDate
    for item in getFile("D://workspace//commitData//"):
        beginName = item.rfind("//")
        endName = item.find(".txt")
        fileName = item[beginName + 2:endName]
        richCode(fileName)
