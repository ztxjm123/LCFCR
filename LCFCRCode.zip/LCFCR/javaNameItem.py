def javaStorage(number, javaName, item):
    outfile = open('result//AntennaPod//' + str(number) + '//' + str(javaName) + '.txt', mode='a', encoding='utf-8')
    outfile.write(item)
    outfile.close()


def javaNameNum(number, javaName):
    re = [line for line in
          open('result//AntennaPod//' + str(number) + '//' + javaName + '.txt', mode='r',
               encoding="utf-8")]
    listNum = []
    for item in re:
        beginNameJava = item.rfind(" and ")
        endNameJava = item.find(".java")
        javaName = item[beginNameJava + 5:endNameJava]
        listNum.append(javaName)
    return len(listNum)


def javaNameSim(number, javaName):
    re = [line for line in
          open('result//AntennaPod//' + str(number) + '//' + javaName + '.txt', mode='r',
               encoding="utf-8")]
    javaNameNum(number, javaName)
    simTotal = 0
    for item in re:
        beginNameSim = item.rfind("的相似度")
        sim = item[beginNameSim + 4:-1]
        simTotal = simTotal + float(sim)
    return simTotal / javaNameNum(number, javaName)


def javaList(number, re, k):
    listNotRepeat = []
    listValue = []
    d = {}
    for item in re:
        beginNameJava = item.rfind(" and ")
        endNameJava = item.find(".java")
        javaName = item[beginNameJava + 5:endNameJava]
        if javaName not in listNotRepeat:
            listNotRepeat.append(javaName)
            javaNum = javaNameNum(number, javaName)
            if javaNum == k:
                sim = javaNameSim(number, javaName)
                # print(str(javaName) + "---出现的是次数---" + str(javaNum) + "---平均相似度值为---" + str(sim))
                d[javaName] = sim
                listValue.append(sim)
    return sorted(d.items(), key=lambda e: e[1], reverse=True)


def printJavaNameList(re, number):
    set_k = set()
    for item in re:
        beginIssueNum = item.find("-")
        endIssueNum = item.find(" and ")
        issueNum = item[beginIssueNum + 12:endIssueNum]
        beginNameJava = item.rfind(" and ")
        endNameJava = item.find(".java")
        javaName = item[beginNameJava + 5:endNameJava]
        # 输出链接的issue的个数
        set_k.add(issueNum)
        # 按java文件名进行存储
        javaStorage(number, javaName, item)
    k = len(set_k)
    # print("该聚类主题一共链接的issue个数为：" + str(k))
    getList = javaList(number, re, k)
    i = 1
    while len(getList) < 5:
        getList.extend(javaList(number, re, k - i))
        i = i + 1
    n = 0
    printList = []
    # n为最后推荐列表的java文件名个数
    while n < 5:
        printList.append(getList[n][0])
        n = n + 1
    # print("该聚类主题对应的java文件名推荐列表为-------" + str(printList))
    print(str(printList))

