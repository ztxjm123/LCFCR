#  主要指标目前有，top-n,precision,recall,MRR
import numpy as np


def computerPrecision(recommendListParam, truthListParam):
    union = [item for item in recommendListParam if (item in truthListParam)]
    return len(union) / len(recommendListParam)


def computerRecall(recommendListParam, truthListParam):
    union = [item for item in recommendListParam if (item in truthListParam)]
    return len(union) / len(truthListParam)


def recommendTrueOrFalse(itemParam, truListParam):
    if itemParam in truListParam:
        return "true"
    if itemParam not in truListParam:
        return "false"


# def computerMRR(recommendListParam, truthListParam):
#     sumValue = []
#     for i in recommendListParam:
#         if recommendTrueOrFalse(i, truthListParam) == "true":
#             location = recommendListParam.index(i) + 1
#             sumValue.append(1/location)
#     return np.sum(sumValue)*1/len(recommendListParam)


def computerMRR(recommendListParam, truthListParam):
    num = 0
    itemList = []
    while num < 5:
        index = recommendTrueOrFalse(recommendListParam[num], truthListParam)
        if index == "true":
            itemList.append(1/(num+1))
            num = 5
        else:
            num = num + 1
    if len(itemList) == 0:
        return 0
    else:
        return itemList[0]


def computerMAP(rankedList, trueList):
    ap = 0
    s = set(trueList)
    hits = [idx for idx, val in enumerate(rankedList) if val in s]
    count = len(hits)
    for i in range(count):
        ap += (i+1) / (hits[i] + 1)
    if count != 0:
        MAP = ap / count
    else:
        MAP = 0
    return MAP


if __name__ == '__main__':
    recommend = [line for line in
                 open("C://Users//Desktop//recommend.txt", mode='r',
                      encoding="utf-8")]
    truth = [line for line in
             open("C://Users//Desktop//truth.txt", mode='r',
                  encoding="utf-8")]
    n = 0
    precisionList = []
    recallList = []
    mrrList = []
    mapList = []
    while n < len(recommend):
        print("-------------------这是第", n)
        # print("这是第", n + 1, "个主题的推荐：", recommend[n], "这是其真相集：", truth[n])
        recommendList = recommend[n].split(",")
        truthList = truth[n].split(",")
        recommendList.pop(len(recommendList) - 1)
        truthList.pop(len(truthList) - 1)
        recommendList.append(recommend[n].split(",")[len(recommendList)].strip("\n"))
        truthList.append(truth[n].split(",")[len(truthList)].strip("\n"))

        Precision = computerPrecision(recommendList, truthList)
        Recall = computerRecall(recommendList, truthList)
        MRR = computerMRR(recommendList, truthList)
        MAP = computerMAP(recommendList, truthList)

        precisionList.append(Precision)
        recallList.append(Recall)
        mrrList.append(MRR)
        mapList.append(MAP)
        print("推荐列表：", recommendList, "真相集列表：", truthList, "\n", "这是Precision：", Precision, "这是Recall：", Recall,
              "这是MRR：", MRR, "这是MAP：", MAP)
        print("----------------------")
        n = n + 1
    # print("----------------------")
    print(np.mean(precisionList), np.mean(recallList), np.mean(mrrList), np.mean(mapList))
